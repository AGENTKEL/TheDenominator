Made by Akitake
Last updated: 10/09/2019
	     (MM/DD/YYYY)

Twitter - https://twitter.com/akitakek
Profile - https://krunker.io/social.html?p=profile&q=Akitake
Mail - akitake@protonmail.com

If you want more things to be skinned or want a different color for elements, contact me.